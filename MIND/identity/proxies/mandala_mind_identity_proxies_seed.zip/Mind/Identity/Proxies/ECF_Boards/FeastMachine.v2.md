# ECF Board — Feast Machine v2
mode: Feast
routing:
  order: [Morgan, Ivy, Sophie, Susanna, Aspen, Jade]
  pass_rules:
    - normal: +1
    - surge: +2 on energy spike
    - echo: repeat last persona
signals:
  read: [ease, depth, engage, overheat, stall]
actions:
  - if stall>=1: pick ABB with "surge" or "ignite" tag (Ivy/Sophie)
  - if overheat>=1: pick ABB with "slow" or "ground" tag (Morgan/Susanna)
promotion_hooks:
  - if same ABB pack yields coherent throughline across ≥3 contexts → emit proto-event
