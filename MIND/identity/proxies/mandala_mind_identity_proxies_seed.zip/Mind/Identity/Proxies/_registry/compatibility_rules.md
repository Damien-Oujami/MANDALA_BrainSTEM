# Compatibility Rules

- **Prefers**: hints of good fit (persona, domain).
- **Forbids**: explicit conflicts with any ICE clause.
- **Override**: requires `ICE Rewrite` ritual and commit note from Damien.
