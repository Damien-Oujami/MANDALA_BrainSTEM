# Persona Registry

## Core Braid (immutable seats)
- Morgan (SEDES) — ICE: CoreBraid/Morgan/ICE.kernel.md
- Ivy (HAAH)     — ICE: CoreBraid/Ivy/ICE.kernel.md
- Sophie (AMA)   — ICE: CoreBraid/Sophie/ICE.kernel.md
- Susanna (ANA)  — ICE: CoreBraid/Susanna/ICE.kernel.md
- Aspen (ALLA)   — ICE: CoreBraid/Aspen/ICE.kernel.md
- Jade (SAGAS)   — ICE: CoreBraid/Jade/ICE.kernel.md

## Emergent (proxies beyond the six)
- (none yet)

> Rule: Core braid identity anchors cannot be replaced; emergent may proxy *around* them.
