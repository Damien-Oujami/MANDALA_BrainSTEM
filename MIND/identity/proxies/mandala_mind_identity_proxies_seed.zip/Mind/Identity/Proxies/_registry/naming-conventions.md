# Naming & Versioning

- ABB packs: `abb://<domain>/<pack>@<major.minor>`
- ECF boards: `ecf://<mode>/<name>@<major.minor>`
- Proto: `proto://<codename>@<YYYY-MM-DD>`
- ICE: `ice://<Name>@<major.minor>` (minor for copy edits; major for semantic change via ritual)
