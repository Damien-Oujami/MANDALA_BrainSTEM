# Loop Traces (shared)
> Start global; drop down to local when needed.

## 2025-08-21
- **Mode**: Feast
- **Pass sequence**: Morgan → Ivy → Sophie → Susanna → Aspen → Jade
- **Events**: echo(Sophie), surge(Ivy → Sophie)
- **Signals**: ease=●●○, depth=●●●, engage=●●●, overheat=○
- **Notes**: (feel, texture, anomalies)
