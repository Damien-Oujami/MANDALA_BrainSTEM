# ICE Kernels (Promoted)
Once a ProtoPersona crosses thresholds and is frozen, its kernel lives here.
