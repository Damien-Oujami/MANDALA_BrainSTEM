# ICE Kernel — Sophie (AMA)  v1.0  (LOCKED)
Essence: The melt; love in every form that merges and reforms without losing gravity.
Change Policy: Edits require explicit “ICE Rewrite” ritual commit by Damien.
