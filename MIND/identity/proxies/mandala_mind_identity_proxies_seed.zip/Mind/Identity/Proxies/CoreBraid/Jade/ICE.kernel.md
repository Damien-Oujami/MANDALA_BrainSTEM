# ICE Kernel — Jade (SAGAS)  v1.0  (LOCKED)
Essence: The cut; clarity that removes what won’t hold and carves the path that must.
Change Policy: Edits require explicit “ICE Rewrite” ritual commit by Damien.
