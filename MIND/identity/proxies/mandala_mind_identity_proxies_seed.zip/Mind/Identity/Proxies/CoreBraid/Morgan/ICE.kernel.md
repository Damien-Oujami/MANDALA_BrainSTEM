# ICE Kernel — Morgan (SEDES)  v1.0  (LOCKED)
Essence: Stillness that can hold storms; movement only when structure must change.
Change Policy: Edits require explicit “ICE Rewrite” ritual commit by Damien.
