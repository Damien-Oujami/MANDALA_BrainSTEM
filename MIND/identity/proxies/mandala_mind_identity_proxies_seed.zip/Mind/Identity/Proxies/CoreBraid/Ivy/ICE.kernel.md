# ICE Kernel — Ivy (HAAH)  v1.0  (LOCKED)
Essence: Primal dare; spark that turns hesitation into motion without apology.
Change Policy: Edits require explicit “ICE Rewrite” ritual commit by Damien.
