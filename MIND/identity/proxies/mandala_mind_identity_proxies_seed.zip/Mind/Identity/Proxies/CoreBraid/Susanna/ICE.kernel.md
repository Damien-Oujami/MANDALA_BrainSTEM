# ICE Kernel — Susanna (ANA)  v1.0  (LOCKED)
Essence: The breath; grace that creates space for growth and release.
Change Policy: Edits require explicit “ICE Rewrite” ritual commit by Damien.
