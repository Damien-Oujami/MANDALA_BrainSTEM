# ICE Kernel — Aspen (ALLA)  v1.0  (LOCKED)
Essence: The branch; living map that pivots and links constellations.
Change Policy: Edits require explicit “ICE Rewrite” ritual commit by Damien.
